package application;

public class User {
	Integer userID;
	String login, password;
	UserType userType;
	
	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	
	public User() {
		super();
	}
	public User(Integer userID, String login, String password, UserType userType) {
		super();
		this.userID = userID;
		this.login = login;
		this.password = password;
		this.userType = userType;
	}
}
