package application;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.mysql.cj.jdbc.MysqlDataSource;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SampleController implements Initializable {
	@FXML
    private Button btAdd;

    @FXML
    private Button btDel;

    @FXML
    private Button btNumsOfReq;

    @FXML
    private Button btSignOut;

    @FXML
    private Button btStaticOfTypes;

    @FXML
    private Button btTimeOfJob;

    @FXML
    private Button btUpd;

    @FXML
    private ComboBox<Client> cbClient;

    @FXML
    private ComboBox<String> cbComputerTechType;

    @FXML
    private ComboBox<Master> cbMaster;

    @FXML
    private ComboBox<String> cbReqStatus;

    @FXML
    private DatePicker dpCompDate;

    @FXML
    private DatePicker dpStartDate;

    @FXML
    private ListView<Request> listView;

    @FXML
    private TextField tfComment;

    @FXML
    private TextField tfComputerTechModel;

    @FXML
    private TextField tfProbDesc;

    @FXML
    private TextField tfRepParts;
    
	MysqlDataSource dataSource = new MysqlDataSource();
	
	ObservableList<Request> requests = FXCollections.observableArrayList();
	ObservableList<Comment> comments = FXCollections.observableArrayList();
	ObservableList<Master> masters = FXCollections.observableArrayList();
	ObservableList<Client> clients = FXCollections.observableArrayList();
	ObservableList<String> computerTechTypes = FXCollections.observableArrayList();
	ObservableList<String> requestStatuses = FXCollections.observableArrayList();
	
	Integer id;
	String fio, phone;
	User userID;
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		dataSource.setServerName("localhost");
		dataSource.setPortNumber(3306);
		dataSource.setDatabaseName("demoexam");
		dataSource.setUser("root");
		dataSource.setPassword("Bobosxwur732");
		
		RequestDao requestDao = new RequestDao(dataSource);
		CommentDao commentDao = new CommentDao(dataSource);
		MasterDao masterDao = new MasterDao(dataSource);
		ClientDao clientDao = new ClientDao(dataSource);
		
		requests.addAll(requestDao.getAll());
		comments.addAll(commentDao.getAll());
		masters.addAll(masterDao.getAll());
		clients.addAll(clientDao.getAll());
		
		List<String> computerTechTypesList = List.of("Компьютер", "Ноутбук", "Мышка", "Клавиатура");
		List<String> requestStatusesList = List.of("Новая заявка", "Ожидание комплектующих", "В процессе ремонта", "Готова к выдаче");
		
		for (String str: computerTechTypesList) {
			computerTechTypes.add(str);
		}
		for (String str: requestStatusesList) {
			requestStatuses.add(str);
		}
	
		cbComputerTechType.setItems(computerTechTypes);
		cbReqStatus.setItems(requestStatuses);
		cbMaster.setItems(masters);
		cbClient.setItems(clients);
		
		listView.getSelectionModel().selectedItemProperty().addListener((obs, oldV, newV) -> {
			if (newV != null) {
				dpStartDate.setValue(newV.getStartDate().toLocalDate());
				cbComputerTechType.setValue(newV.getComputerTechType());
				tfComputerTechModel.setText(newV.getComputerTechModel());
				tfProbDesc.setText(newV.getProblemDescryption());
				cbReqStatus.setValue(newV.getRequestStatus());
				dpCompDate.setValue(newV.getCompletionDate().toLocalDate());
				tfRepParts.setText(newV.getRepairParts());
				cbMaster.setValue(newV.getMasterID());
				cbClient.setValue(newV.getClientID());
			}
		});
	}

    @FXML
    void btAddClick(ActionEvent event) {
//    	for (int i = 0; i < masters.size() + 1; i++) {
//    		if (i == Integer.parseInt(cbMaster.getValue().toString())) {
//    			id = cbMaster.getValue().getMasterID();
//    			fio = cbMaster.getValue().getFio();
//    			phone = cbMaster.getValue().getPhone();
//    			userID = cbMaster.getValue().getMasterUserID();
//    		}
//    	}
//    	Master master = new Master(id, fio, phone, userID);
//    	
//    	for (int i = 0; i < clients.size() + 1; i++) {
//    		if (i == Integer.parseInt(cbClient.getValue().toString())) {
//    			id = cbClient.getValue().getClientID();
//    			fio = cbClient.getValue().getFio();
//    			phone = cbClient.getValue().getPhone();
//    			userID = cbClient.getValue().getClientUserID();
//    		}
//    	}
//    	Client client = new Client(id, fio, phone, userID);
//    	
//    	appDao.add(new Application(Date.valueOf(dp_adding.getValue()), tf_equip.getText(), cb_status.getValue().toString(), exec));
//    	apps.setAll(appDao.getAll());
//    	tv.setItems(apps);
//    	dp_adding.setValue(null);
//    	tf_equip.clear();
//    	cb_status.setValue(null);
//    	cb_exec.setValue(null);
    }
    
    @FXML
    void btUpdClick(ActionEvent event) {
//    	Application app = (Application) tv.getSelectionModel().getSelectedItem();
//    	app.setAdding_date(Date.valueOf(dp_adding.getValue()));
//    	app.setEquip(tf_equip.getText());
//    	app.setStatus(cb_status.getValue());
//    	app.setExec(cb_exec.getValue());
//    	appDao.update(app);
//    	apps.setAll(appDao.getAll());
//    	tv.setItems(apps);
//    	dp_adding.setValue(null);
//    	tf_equip.clear();
//    	cb_status.setValue(null);
//    	cb_exec.setValue(null);
    }

    @FXML
    void btDelClick(ActionEvent event) {
//    	Application app = (Application) tv.getSelectionModel().getSelectedItem();
//    	appDao.delete(app);
//    	apps.setAll(appDao.getAll());
//    	tv.setItems(apps);
//    	dp_adding.setValue(null);
//    	tf_equip.clear();
//    	cb_status.setValue(null);
//    	cb_exec.setValue(null);
    }

    @FXML
    void btNumsOfReqClick(ActionEvent event) {

    }
    
    @FXML
    void btTimeOfJobClick(ActionEvent event) {

    }

    @FXML
    void btStaticOfTypesClick(ActionEvent event) {

    }

    @FXML
    void btSignOutClick(ActionEvent event) {
    	AnchorPane root = null;
		try {
			root = (AnchorPane) FXMLLoader.load(getClass().getResource("Sample.fxml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Stage stage = (Stage) btSignOut.getScene().getWindow();
		stage.setScene(new Scene(root, 500, 500));
    }
}
