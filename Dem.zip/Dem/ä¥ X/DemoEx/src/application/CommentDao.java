package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class CommentDao {
	JdbcTemplate jdbcTemplate;
	
	public CommentDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	List<Comment> getAll() {
		List<Comment> comments = jdbcTemplate.query("SELECT * FROM comment",
											(resultSet, rowNum) -> {
												Comment comment = new Comment();
												comment.setCommentID(resultSet.getInt("commentID"));
												comment.setMessage(resultSet.getString("message"));
												comment.setRequestID(new Request());
												return comment;
											});
		return comments;
	}
	
	void add(Comment comment) {
		jdbcTemplate.update("INSERT INTO comment (message, requestID) VALUES (?, ?, ?)",
							comment.getMessage(), comment.getRequestID());
	}
	
	void upd(Comment comment) {
		jdbcTemplate.update("UPDATE comment SET message = ?, requestID = ? WHERE commentID = ?",
							comment.getMessage(), comment.getRequestID(), comment.getCommentID());
	}
	
	void del(Comment comment) {
		jdbcTemplate.update("DELETE FROM comment WHERE commentID = ?",
							comment.getCommentID());
	}
}
