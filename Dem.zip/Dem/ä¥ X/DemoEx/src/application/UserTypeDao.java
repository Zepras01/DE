package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class UserTypeDao {
	JdbcTemplate jdbcTemplate;
	
	public UserTypeDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	List<UserType> getAll() {
		List<UserType> userTypes = jdbcTemplate.query("SELECT * FROM userType", 
													  (resultSet, rowNum) -> {
														  UserType userType = new UserType();
														  userType.setUserTypeID(resultSet.getInt("userTypeID"));
														  userType.setType(resultSet.getString("type"));
														  return userType;
													  });
		return userTypes;
	}
	
	void add(UserType userType) {
		jdbcTemplate.update("INSERT INTO userType (type) VALUES (?)",
							userType.getType());
	}
	
	void upd(UserType userType) {
		jdbcTemplate.update("UPDATE userType SET type = ? WHERE userTypeID = ?",
							userType.getType(), userType.getUserTypeID());
	}
	
	void del(UserType userType) {
		jdbcTemplate.update("DELETE FROM userType WHERE userTypeID = ?",
							userType.getUserTypeID());
	}
}
