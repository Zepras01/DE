package application;

public class Comment {
	Integer commentID;
	String message;
	Request requestID;
	
	public Integer getCommentID() {
		return commentID;
	}
	public void setCommentID(Integer commentID) {
		this.commentID = commentID;
	}
	
	public Request getRequestID() {
		return requestID;
	}
	public void setRequestID(Request requestID) {
		this.requestID = requestID;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Comment() {
		super();
	}
	public Comment(Integer commentID, Request requestID, String message) {
		super();
		this.commentID = commentID;
		this.requestID = requestID;
		this.message = message;
	}
}
