package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class UserDao {
	JdbcTemplate jdbcTemplate;
	
	public UserDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	List<User> getAll() {
		List<User> users = jdbcTemplate.query("SELECT * FROM user INNER JOIN userType WHERE user.userTypeID = userType.userTypeID",
											(resultSet, rowNum) -> {
												User user = new User();
												user.setUserID(resultSet.getInt("userID"));
												user.setLogin(resultSet.getString("login"));
												user.setPassword(resultSet.getString("password"));
												user.setUserType(new UserType(resultSet.getInt("userTypeID"), resultSet.getString("type")));
												return user;
											});
		return users;
	}
	
	void add(User user) {
		jdbcTemplate.update("INSERT INTO user (login, password, userTypeID) VALUES (?, ?, ?)",
							user.getLogin(), user.getPassword(), user.getUserType());
	}
	
	void upd(User user) {
		jdbcTemplate.update("UPDATE user SET login = ?, password = ?, userTypeID = ? WHERE userID = ?",
							user.getLogin(), user.getPassword(), user.getUserType(), user.getUserID());
	}
	
	void del(User user) {
		jdbcTemplate.update("DELETE FROM user WHERE userID = ?",
							user.getUserID());
	}
}
