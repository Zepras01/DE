package application;

public class UserType {
	Integer userTypeID;
	String type;
	
	public Integer getUserTypeID() {
		return userTypeID;
	}
	public void setUserTypeID(Integer userTypeID) {
		this.userTypeID = userTypeID;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public UserType() {
		super();
	}
	public UserType(Integer userTypeID, String type) {
		super();
		this.userTypeID = userTypeID;
		this.type = type;
	}
}
