package application;

public class Master {
	Integer masterID;
	String fio, phone;
	User masterUserID;
	
	public Integer getMasterID() {
		return masterID;
	}
	public void setMasterID(Integer masterID) {
		this.masterID = masterID;
	}
	
	public String getFio() {
		return fio;
	}
	public void setFio(String fio) {
		this.fio = fio;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public User getMasterUserID() {
		return masterUserID;
	}
	public void setMasterUserID(User masterUserID) {
		this.masterUserID = masterUserID;
	}
	
	public Master() {
		super();
	}
	public Master(Integer masterID, String fio, String phone, User masterUserID) {
		super();
		this.masterID = masterID;
		this.fio = fio;
		this.phone = phone;
		this.masterUserID = masterUserID;
	}
}
