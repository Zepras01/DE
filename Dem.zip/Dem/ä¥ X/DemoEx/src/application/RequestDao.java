package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class RequestDao {
	JdbcTemplate jdbcTemplate;
	
	public RequestDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	List<Request> getAll() {
		// Доделать запрос
		List<Request> requests = jdbcTemplate.query("SELECT * FROM request INNER JOIN master INNER JOIN client INNER JOIN user INNER JOIN userType WHERE request.masterID = master.masterID AND request.clientID = client.clientID and client.clientUserID = user.userID and master.masterUserID = user.userID and user.userTypeID = userType.userTypeID",
													(resultSet, rowNum) -> {
														Request request = new Request();
														request.setRequestID(resultSet.getInt("requestID"));
														request.setStartDate(resultSet.getDate("startDate"));
														request.setComputerTechType(resultSet.getString("computerTechType"));
														request.setComputerTechModel(resultSet.getString("computerTechModel"));
														request.setProblemDescryption(resultSet.getString("problemDescryption"));
														request.setRequestStatus(resultSet.getString("requestStatus"));
														request.setCompletionDate(resultSet.getDate("completionDate"));
														request.setRepairParts(resultSet.getString("repairParts"));
														request.setMasterID(new Master(resultSet.getInt("masterID"), resultSet.getString("fio"), resultSet.getString("phone"),
																						new User(resultSet.getInt("userID"), resultSet.getString("login"), resultSet.getString("password"), 
																								 new UserType(resultSet.getInt("userTypeID"), resultSet.getString("type")))));
														request.setClientID(new Client(resultSet.getInt("clientID"), resultSet.getString("fio"), resultSet.getString("phone"),
																						new User(resultSet.getInt("userID"), resultSet.getString("login"), resultSet.getString("password"), 
																								 new UserType(resultSet.getInt("userTypeID"), resultSet.getString("type")))));
														return request;
													});
		return requests;
	}
	
	void add(Request request) {
		jdbcTemplate.update("INSERT INTO request (startDate, computerTechType, computerTechModel, problemDescryption, "
							+ "requestStatus, completionDate, repairParts, masterID, clientID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
							request.getStartDate(), request.getComputerTechType(), request.getComputerTechModel(), request.getProblemDescryption(), 
							request.getRequestStatus(), request.getCompletionDate(), request.getRepairParts(),
							request.getMasterID(), request.getClientID());
	}
	
	void upd(Request request) {
		jdbcTemplate.update("UPDATE request SET startDate = ?, computerTechType = ?, computerTechModel = ?, problemDescryption = ?, "
							+ "requestStatus = ?, completionDate = ?, repairParts = ?, masterID = ?, clientID = ? WHERE requestID = ?",
							request.getStartDate(), request.getComputerTechType(), request.getComputerTechModel(), request.getProblemDescryption(), 
							request.getRequestStatus(), request.getCompletionDate(), request.getRepairParts(),
							request.getMasterID(), request.getClientID(), request.getRequestID());
	}
	
	void del(Request request) {
		jdbcTemplate.update("DELETE FROM request WHERE requestID = ?",
							request.getRequestID());
	}
}
