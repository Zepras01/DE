package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class ClientDao {
	JdbcTemplate jdbcTemplate;
	
	public ClientDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	List<Client> getAll() {
		List<Client> clients = jdbcTemplate.query("SELECT * FROM userType", 
													(resultSet, rowNum) -> {
														Client client = new Client();
														client.setClientID(resultSet.getInt("clientID"));
														client.setFio(resultSet.getString("fio"));
														client.setPhone(resultSet.getString("phone"));
														client.setClientUserID(new User(resultSet.getInt("userID"), resultSet.getString("login"), resultSet.getString("password"), 
																				new UserType(resultSet.getInt("userTypeID"), resultSet.getString("type"))));
														return client;
													});
		return clients;
	}
	
	void add(Client client) {
		jdbcTemplate.update("INSERT INTO client (fio, phone, clientUserID) VALUES (?, ?, ?)", 
							client.getFio(), client.getPhone(), client.getClientUserID());
	}
	
	void upd(Client client) {
		jdbcTemplate.update("UPDATE client SET fio = ?, phone = ?, clientUserID = ? WHERE clientID = ?", 
							client.getFio(), client.getPhone(), client.getClientUserID(), client.getClientID());
	}
	
	void del(Client client) {
		jdbcTemplate.update("DELETE FROM client WHERE clientID = ?", 
							client.getClientID());
	}
}
