package application;

public class Client {
	Integer clientID;
	String fio, phone;
	User clientUserID;
	
	public Integer getClientID() {
		return clientID;
	}
	public void setClientID(Integer clientID) {
		this.clientID = clientID;
	}
	
	public String getFio() {
		return fio;
	}
	public void setFio(String fio) {
		this.fio = fio;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public User getClientUserID() {
		return clientUserID;
	}
	public void setClientUserID(User clientUserID) {
		this.clientUserID = clientUserID;
	}
	
	public Client() {
		super();
	}
	public Client(Integer clientID, String fio, String phone, User clientUserID) {
		super();
		this.clientID = clientID;
		this.fio = fio;
		this.phone = phone;
		this.clientUserID = clientUserID;
	}
}
