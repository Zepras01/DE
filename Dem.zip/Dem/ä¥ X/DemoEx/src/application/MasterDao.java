package application;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.cj.jdbc.MysqlDataSource;

public class MasterDao {
	JdbcTemplate jdbcTemplate;
	
	public MasterDao(MysqlDataSource dataSource) {
		super();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	List<Master> getAll() {
		List<Master> masters = jdbcTemplate.query("SELECT * FROM userType", 
													(resultSet, rowNum) -> {
														Master master = new Master();
														master.setMasterID(resultSet.getInt("masterID"));
														master.setFio(resultSet.getString("fio"));
														master.setPhone(resultSet.getString("phone"));
														master.setMasterUserID(new User(resultSet.getInt("userID"), resultSet.getString("login"), resultSet.getString("password"), 
																				new UserType(resultSet.getInt("userTypeID"), resultSet.getString("type"))));
														return master;
													});
		return masters;
	}
	
	void add(Master master) {
		jdbcTemplate.update("INSERT INTO master (fio, phone, masterUserID) VALUES (?, ?, ?)", 
							master.getFio(), master.getPhone(), master.getMasterUserID());
	}
	
	void upd(Master master) {
		jdbcTemplate.update("UPDATE master SET fio = ?, phone = ?, masterUserID = ? WHERE masterID = ?", 
							master.getFio(), master.getPhone(), master.getMasterUserID(), master.getMasterID());
	}
	
	void del(Master master) {
		jdbcTemplate.update("DELETE FROM master WHERE masterID = ?", 
							master.getMasterID());
	}
}
