package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.mysql.cj.jdbc.MysqlDataSource;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class AuthController implements Initializable {

    @FXML
    private Button btSignIn;

    @FXML
    private TextField tfLogin;

    @FXML
    private TextField tfPass;
    
    MysqlDataSource dataSource = new MysqlDataSource();
    ObservableList<User> users = FXCollections.observableArrayList();
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		dataSource.setServerName("localhost");
		dataSource.setPortNumber(3306);
		dataSource.setDatabaseName("demoexam");
		dataSource.setUser("root");
		dataSource.setPassword("Bobosxwur732");
		
		UserDao userDao = new UserDao(dataSource);
		
		users.setAll(userDao.getAll());
	}

    @FXML
    void btSignInClick(ActionEvent event) {
    	ArrayList<String> login = new ArrayList<String>();
    	ArrayList<String> password = new ArrayList<String>();
    	for (User u: users) {
    		login.add(u.getLogin());
    		password.add(u.getPassword());
    	}
    	
    	boolean flag = false;
    	if (tfLogin.getText().isEmpty() || tfPass.getText().isEmpty()) {
    		Alert alert = new Alert(AlertType.ERROR, "Все поля должны быть заполнены");
    		alert.showAndWait();
    	}
    	else {
    		for (int i = 0; i < users.size(); i++) {
    			if ((tfLogin.getText().equals(login.get(i)) == true) &&
    			(tfPass.getText().equals(password.get(i)) == true)) {
    				flag = true;
    				break;
    			}
    		}
    		
    		if (flag == false) {
    	    	Alert alert = new Alert(AlertType.ERROR, "Такого пользователя не существует");
    	    	alert.showAndWait();
    		}
    		else {
    			BorderPane root = null;
				try {
					root = (BorderPane) FXMLLoader.load(getClass().getResource("Sample.fxml"));
					Stage stage = (Stage) btSignIn.getScene().getWindow();
					stage.setScene(new Scene(root, 1019, 712));
				} catch (IOException e) {
					e.printStackTrace();
				}

    		}
    	}
    }
}
