package application;

import java.sql.Date;

public class Request {
	Integer requestID;
	Date startDate, completionDate;
	String computerTechType, computerTechModel, requestStatus, problemDescryption, repairParts;
	Master masterID;
	Client clientID;
	
	public Integer getRequestID() {
		return requestID;
	}
	public void setRequestID(Integer requestID) {
		this.requestID = requestID;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}
	
	public String getComputerTechType() {
		return computerTechType;
	}
	public void setComputerTechType(String computerTechType) {
		this.computerTechType = computerTechType;
	}
	
	public String getComputerTechModel() {
		return computerTechModel;
	}
	public void setComputerTechModel(String computerTechModel) {
		this.computerTechModel = computerTechModel;
	}
	
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	
	public String getProblemDescryption() {
		return problemDescryption;
	}
	public void setProblemDescryption(String problemDescryption) {
		this.problemDescryption = problemDescryption;
	}
	
	public String getRepairParts() {
		return repairParts;
	}
	public void setRepairParts(String repairParts) {
		this.repairParts = repairParts;
	}
	
	public Master getMasterID() {
		return masterID;
	}
	public void setMasterID(Master masterID) {
		this.masterID = masterID;
	}
	
	public Client getClientID() {
		return clientID;
	}
	public void setClientID(Client clientID) {
		this.clientID = clientID;
	}
	
	public Request() {
		super();
	}
	public Request(Integer requestID, Date startDate, String computerTechType, String computerTechModel, String problemDescryption, 
			String requestStatus, Date completionDate, String repairParts, Master masterID, Client clientID) {
		super();
		this.requestID = requestID;
		this.startDate = startDate;
		this.computerTechType = computerTechType;
		this.computerTechModel = computerTechModel;
		this.problemDescryption = problemDescryption;
		this.requestStatus = requestStatus;
		this.completionDate = completionDate;
		this.repairParts = repairParts;
		this.masterID = masterID;
		this.clientID = clientID;
	}
}
