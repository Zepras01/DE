open module DemoEx {
	requires javafx.controls;
	requires javafx.fxml;
	requires mysql.connector.j;
	requires javafx.base;
	requires spring.jdbc;
	requires java.sql;
	requires javafx.graphics;
}
